
library(shiny)
library(tidyverse)
library(googledrive)
library(aws.s3)

Sys.setenv("AWS_ACCESS_KEY_ID" = "AKIAVCZUBDX3AIQSC4Z5",
           "AWS_SECRET_ACCESS_KEY" = "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",
           "AWS_DEFAULT_REGION" = "us-east-2")

teams <- s3read_using(FUN = read_csv, object = "HiddenPondsTeams.csv", bucket = "hidden-ponds-bags")

records <- s3read_using(FUN = read_csv, object = "2019 Hidden Ponds Bags.csv", bucket = "hidden-ponds-bags")

gameLog <- s3read_using(FUN = read_csv, object = "HiddenPondsGameLog.csv", bucket = "hidden-ponds-bags")


upDateRecords <- gameLog %>% 
  mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
         lose = if_else(Team1Score<Team2Score, Team1, Team2),
         scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
         scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
         winningScore = pmax(Team1Score, Team2Score),
         losingScore = pmin(Team1Score, Team2Score)) %>% 
  select(win, lose, winningScore, losingScore, scoreDifferenceWin, scoreDifferenceLose) %>% 
  gather(`win`, `lose`,
         key = 'Result', value = 'Team') %>% 
  mutate(scoreDifference = if_else(Result == 'win', scoreDifferenceWin, 
                                   scoreDifferenceLose),
         scoreFinal = if_else(Result == 'win', winningScore,
                              losingScore)) %>%
  select(Team, Result, scoreDifference, scoreFinal) %>% 
  group_by(Team) %>% 
  summarise(Wins = sum(Result == 'win', na.rm = TRUE),
            Loses = sum(Result == 'lose', na.rm = TRUE),
            AvgDifference = mean(scoreDifference, na.rm=TRUE),
            AvgScore = mean(scoreFinal, na.rm = TRUE)) %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/(TotalPlayed)) %>% 
  left_join(teams, by = c('Team' = 'Team'))

recordMerge <- records %>% 
  left_join(upDateRecords, by = c("Team", "Player1", "Player2")) %>%
  group_by(Team) %>% 
  mutate(Wins = sum(Wins.x, Wins.y, na.rm = TRUE),
         Loses = sum(Loses.x, Loses.y, na.rm = TRUE),
         TotalPlayed = Wins + Loses,
         Percentage = Wins/TotalPlayed) %>% 
  select(Team, Player1, Player2, Wins, Loses, TotalPlayed, Percentage)

records <- recordMerge %>% 
  ungroup() %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/(TotalPlayed))

player2 <- recordMerge %>% 
  ungroup() %>% 
  select(Player2, Wins, Loses) %>% 
  rename(Player1 = Player2)

playerStandings <- records %>% 
  select(Player1, Wins, Loses) %>% 
  rbind(player2) %>% 
  group_by(Player1) %>% 
  summarise(Wins = sum(Wins),
            Loses = sum(Loses)) %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/TotalPlayed
  ) %>% 
  arrange(desc(Percentage), desc(Wins)) %>% 
  head()


tempData <- gameLog %>% 
  filter(year(Time) == year(today())) %>% 
  mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
         lose = if_else(Team1Score<Team2Score, Team1, Team2),
         scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
         scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
         winningScore = pmax(Team1Score, Team2Score),
         losingScore = pmin(Team1Score, Team2Score)) %>% 
  select(win, lose, winningScore, losingScore,
         scoreDifferenceWin, scoreDifferenceLose) %>% 
  gather(`win`, `lose`, key = 'Result', value = 'Team') %>% 
  mutate(scoreDifference = if_else(Result == 'win', scoreDifferenceWin, 
                                   scoreDifferenceLose),
         scoreFinal = if_else(Result == 'win', winningScore,
                              losingScore)) %>%
  select(Team, Result, scoreDifference, scoreFinal) %>% 
  group_by(Team) %>% 
  summarise(Streak = paste0(str_to_upper(str_extract(Result, "^.{1}")), collapse = ""),
            lastFive = str_sub(Streak, start = -5, end = -1),
            Wins = sum(Result == 'win', na.rm = TRUE),
            Loses = sum(Result == 'lose', na.rm = TRUE),
            AvgDifference = round(mean(scoreDifference, na.rm = TRUE), 2),
            AvgScore = round(mean(scoreFinal, na.rm = TRUE), 2)) %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/(TotalPlayed)) %>% 
  left_join(records, by = c('Team')) %>% 
  group_by(Team) %>% 
  mutate(Wins = sum(Wins.x, Wins.y, na.rm = TRUE),
         Loses = sum(Loses.x, Loses.y, na.rm = TRUE),
         TotalPlayed =Wins + Loses,
         Percentage = round(Wins/TotalPlayed, 2)) %>% 
  select(Team, Player1, Player2, Wins, Loses, TotalPlayed, Percentage, AvgScore, AvgDifference,lastFive)

tempData




HTHWins <- gameLog %>% 
  #filter(year(Time) == year(today())) %>% 
  mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
         lose = if_else(Team1Score<Team2Score, Team1, Team2),
         scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
         scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
         winningScore = pmax(Team1Score, Team2Score),
         losingScore = pmin(Team1Score, Team2Score),
         matchUp = paste(win, "vs", lose),
         matchUp2 = paste(lose, 'vs', win)) %>% 
  select(matchUp, matchUp2, win, lose) %>% 
  mutate(winStr = str_split(matchUp, " ")[[1]][[1]],
         matchUpClean = ifelse(winStr == win, matchUp, matchUp2)) %>% 
  select(matchUpClean, win, lose) %>% 
  group_by(win, matchUpClean) %>% 
  mutate(winTotal = n()) %>% 
  ungroup() %>% 
  distinct()

HTHWinsFilter <- HTHWins %>% 
  filter((win == teams$Team[[1]] & lose == teams$Team[[2]]) |
           (win == teams$Team[[2]] & lose == teams$Team[[1]]))

ggplot(HTHWinsFilter, aes(x = win, y = winTotal, fill = win)) + geom_col()

  
  
HTHLoses <- gameLog %>% 
  #filter(year(Time) == year(today())) %>% 
  mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
         lose = if_else(Team1Score<Team2Score, Team1, Team2),
         scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
         scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
         winningScore = pmax(Team1Score, Team2Score),
         losingScore = pmin(Team1Score, Team2Score),
         matchUp = paste(win, "vs", lose),
         matchUp2 = paste(lose, 'vs', win)) %>% 
  select(matchUp, matchUp2, win, lose) %>% 
  mutate(winStr = str_split(matchUp, " ")[[1]][[1]],
         matchUpClean = ifelse(winStr == win, matchUp, matchUp2)) %>% 
  select(matchUpClean, win, lose) %>% 
  group_by(lose, matchUpClean) %>% 
  summarize(loses = n())

HTHOverall <- HTHWins %>% 
  left_join(HTHLoses) %>% 
  mutate(totalPlayed = wins + loses)


