# Shiny App to Track Bags records

This is a shiny app to track our neighborhood bags records.  All files are stored and updated in a google drive.  The app is used to input gamelogs.  The gamelog is then transformed to create stats, etc. that can then be graphed and put in tables.


