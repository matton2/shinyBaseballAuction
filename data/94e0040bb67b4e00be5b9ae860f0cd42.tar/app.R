#App to update and view 2019 bags scores in hidden ponds

library(shiny)
library(tidyverse)
library(googledrive)
library(DT)
library(shinyalert)
library(lubridate)
library(aws.s3)

useShinyalert()

keys <- read_csv('rootkey.csv', col_names = FALSE)

Sys.setenv("AWS_ACCESS_KEY_ID" = "AKIAVCZUBDX3AIQSC4Z5",
           "AWS_SECRET_ACCESS_KEY" = "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",
           "AWS_DEFAULT_REGION" = "us-east-2")

bucketlist("hidden-ponds-bags")

teams <- s3read_using(FUN = read_csv, object = "HiddenPondsTeams.csv", bucket = "hidden-ponds-bags")

records <- s3read_using(FUN = read_csv, object = "2019 Hidden Ponds Bags.csv", bucket = "hidden-ponds-bags")

gameLog <- s3read_using(FUN = read_csv, object = "HiddenPondsGameLog.csv", bucket = "hidden-ponds-bags")

colfunc <- colorRampPalette(c("orange", 'white', "brown"))
colors <- colfunc(10)


combos <- crossing(var1 = c("W","L"), 
                   var2 = c("W", "L"), 
                   var3 = c("W", "L"), 
                   var4 = c("W", "L"), 
                   var5 = c("W", "L")) %>% 
    mutate(combos = paste0(var1, var2, var3, var4, var5),
           color = ifelse(str_ends(combos, "LLLLL"), colors[[10]], 
                          ifelse(str_ends(combos, "WWWWW"), colors[[1]],
                                 ifelse(str_ends(combos, "LLLL"), colors[[9]], 
                                        ifelse(str_ends(combos, "WWWW"), colors[[2]],
                                               ifelse(str_ends(combos, "LLL"), colors[[8]], 
                                                      ifelse(str_ends(combos, "WWW"), colors[[3]],
                                                             ifelse(str_ends(combos, "LL"), colors[[7]],
                                                                    ifelse(str_ends(combos, "WW"), colors[[4]],
                                                                           ifelse(str_ends(combos, "L"), colors[[6]],
                                                                                  colors[[5]]))))))))))

# Define UI for application ####

ui <- fluidPage(
    
    # Application title
    titlePanel("Hidden Ponds Bags Records"),
    
    sidebarLayout(
        sidebarPanel(
            uiOutput('update1'),
            numericInput('score1', "Enter Team 1 Score", value = 0, step = 1),
            uiOutput('update2'),
            uiOutput('teamCheck'),
            numericInput('score2', "Enter Team 2 Score", value = 0), step = 1,
            uiOutput('scoreCheck'),
            fluidRow( 
                actionButton('update', "Update Standings"),
                actionButton('newTeam', "Add a New Team"),
                actionButton('updateRecord', "Make a Correction")
            )
        ),
        
        mainPanel(
            tabsetPanel(
                tabPanel(
                    title = paste(year(today()), "Overall"),
                    h2(paste(year(today()), "Overall Team Standings")),
                    dataTableOutput('standings'),
                    h2("Individual Player Standings"),
                    dataTableOutput('indStandings'),
                    h2("All Teams with a Game Played"),
                    dataTableOutput('teams')
                ),
                tabPanel(
                    title = "Lifetime Overall",
                    h2("Lifetime Overall Team Standings"),
                    dataTableOutput('overallStanding'),
                    h2("Lifetime Individual Standings"),
                    dataTableOutput('lifeIndStanding'),
                    h2("Lifetime All Teams with a Game Played"),
                    dataTableOutput('lifetimeTeams')
                ),
                tabPanel(
                    title = "Head to Head Overall",
                    fluidRow(
                        column(6, uiOutput("h2h1")),
                        column(6, uiOutput("h2h2"))
                    ),
                    fluidRow(
                        verbatimTextOutput('h2hText')
                    ),
                    fluidRow(
                        plotOutput('h2hPlot')
                    )
                )
            )

        )
    )
)

#define server for app####
server <- function(input, output, session) {
    
    rv <- reactiveValues()
    
    rv$teams <- teams
    
    rv$gL <- gameLog
    
    # UI for team input 1 ------
    output$update1 <- renderUI({
        
        selectInput('team1', 'Select Team 1', 
                    choices = as.list(unique(rv$teams$Team)),
                    selected = rv$teams$Team[[1]])
    })
    #ui for team input 2 -------
    output$update2 <- renderUI({
        selectInput('team2', 'Select Team 2', 
                    choices = as.list(unique(rv$teams$Team)),
                    selected = rv$teams$Team[[2]])
        
    })
    
    # ui input for head to head team 1
    output$h2h1 <- renderUI({
        
        selectInput('team1H2H', 'Select Team 1', 
                    choices = as.list(unique(rv$teams$Team)),
                    selected = rv$teams$Team[[1]])
    })
    #ui for team input 2 -------
    output$h2h2 <- renderUI({
        selectInput('team2H2H', 'Select Team 2', 
                    choices = as.list(unique(rv$teams$Team)),
                    selected = rv$teams$Team[[2]])
        
    })
    
    
    output$teamCheck <- renderUI({
        if(input$team1 == input$team2){
            return(
                p(tags$span(style="color:red", "Please Enter Two Different Teams"), sep = "")
            )
        }
    })
    
    output$scoreCheck <- renderUI({
        if(input$score1 < 21 & input$score2 < 21) {
            return(
                p(tags$span(style="color:red", "One Team Needs 21 or More"), sep = "")
            )
        }
        
        if(input$score1 == input$score2) {
            return(
                p(tags$span(style="color:red", "One Team Needs More Points"), sep = "")
            )
        }
    })
    
    
    observeEvent(input$update, {
        

        rv$gL <- rv$gL %>% 
            add_row(Time = lubridate::today(),
                    Team1 = input$team1,
                    Team1Score = input$score1,
                    Team2 = input$team2,
                    Team2Score = input$score2)
        

        s3write_using(rv$gL, FUN = write_csv, object = "HiddenPondsGameLog.csv", bucket = "hidden-ponds-bags")
    
    })
    
    currentYearRecords <- reactive({
        
        tempData <- rv$gL %>% 
            filter(year(Time) == year(today())) %>% 
            mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
                   lose = if_else(Team1Score<Team2Score, Team1, Team2),
                   scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
                   scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
                   winningScore = pmax(Team1Score, Team2Score),
                   losingScore = pmin(Team1Score, Team2Score)) %>% 
            select(win, lose, winningScore, losingScore,
                   scoreDifferenceWin, scoreDifferenceLose) %>% 
            gather(`win`, `lose`, key = 'Result', value = 'Team') %>% 
            mutate(scoreDifference = if_else(Result == 'win', scoreDifferenceWin, 
                                             scoreDifferenceLose),
                   scoreFinal = if_else(Result == 'win', winningScore,
                                        losingScore)) %>%
            select(Team, Result, scoreDifference, scoreFinal) %>% 
            group_by(Team) %>% 
            summarise(
                Streak = paste0(str_to_upper(str_extract(Result, "^.{1}")), collapse = ""),
                lastFive = str_sub(Streak, start = -5, end = -1),
                Wins = sum(Result == 'win', na.rm = TRUE),
                      Loses = sum(Result == 'lose', na.rm = TRUE),
                      AvgDifference = round(mean(scoreDifference, na.rm = TRUE), 2),
                      AvgScore = round(mean(scoreFinal, na.rm = TRUE), 2)) %>% 
            mutate(TotalPlayed = Wins + Loses,
                   Percentage = round(Wins/(TotalPlayed),2)) %>% 
            left_join(rv$teams, by = c('Team')) %>% 
            # full_join(records, by = c("Team", "Player1", "Player2")) %>%
            # group_by(Team) %>% 
            # mutate(Wins = sum(Wins.x, Wins.y, na.rm = TRUE),
            #        Loses = sum(Loses.x, Loses.y, na.rm = TRUE),
            #        TotalPlayed =Wins + Loses,
            #        Percentage = round(Wins/TotalPlayed, 2)) %>% 
            select(Team, Player1, Player2, Wins, Loses, TotalPlayed, Percentage, AvgScore, AvgDifference,lastFive)
        
        tempData
    })
    
    overallRecords <- reactive({
        
        tempData <- rv$gL %>% 
            mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
                   lose = if_else(Team1Score<Team2Score, Team1, Team2),
                   scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
                   scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
                   winningScore = pmax(Team1Score, Team2Score),
                   losingScore = pmin(Team1Score, Team2Score)) %>% 
            select(win, lose, winningScore, losingScore,
                   scoreDifferenceWin, scoreDifferenceLose) %>% 
            gather(`win`, `lose`, key = 'Result', value = 'Team') %>% 
            mutate(scoreDifference = if_else(Result == 'win', scoreDifferenceWin, 
                                             scoreDifferenceLose),
                   scoreFinal = if_else(Result == 'win', winningScore,
                                        losingScore)) %>%
            select(Team, Result, scoreDifference, scoreFinal) %>% 
            group_by(Team) %>% 
            summarise( Streak = paste0(str_to_upper(str_extract(Result, "^.{1}")), collapse = ""),
                       lastFive = str_sub(Streak, start = -5, end = -1),
                Wins = sum(Result == 'win', na.rm = TRUE),
                      Loses = sum(Result == 'lose', na.rm = TRUE),
                      AvgDifference = round(mean(scoreDifference, na.rm = TRUE), 2),
                      AvgScore = round(mean(scoreFinal, na.rm = TRUE), 2)) %>% 
            mutate(TotalPlayed = Wins + Loses,
                   Percentage = Wins/(TotalPlayed)) %>% 
            left_join(rv$teams, by = c('Team')) %>% 
            full_join(records, by = c("Team", "Player1", "Player2")) %>%
            group_by(Team) %>% 
            mutate(Wins = sum(Wins.x, Wins.y, na.rm = TRUE),
                   Loses = sum(Loses.x, Loses.y, na.rm = TRUE),
                   TotalPlayed =Wins + Loses,
                   Percentage = round(Wins/TotalPlayed, 2)) %>% 
            select(Team, Player1, Player2, Wins, Loses, TotalPlayed, Percentage, AvgScore, AvgDifference, lastFive)
        
        tempData
        
    })
    
    observeEvent(input$newTeam, {
        showModal( modalDialog(
            title = "Add New Team",
            textInput('newTeamName', "Enter New Team Name"),
            textInput('player1', "Enter 1st Player Name"),
            textInput('player2', "Enter 2nd Player Name"),
            easyClose = TRUE,
            
            footer = tagList(
                modalButton("Cancel"),
                actionButton("add", "OK")
            )
        ))
        
    })
    
    observeEvent(input$add, {
        
        rv$teams <- rv$teams %>% 
            add_row(Team = input$newTeamName, 
                    Player1 = input$player1,
                    Player2 = input$player2)
        
        s3write_using(rv$teams, FUN = write_csv, object = "HiddenPondsTeams.csv", bucket = "hidden-ponds-bags")
        
        removeModal()
    })
    
    observeEvent(input$updateRecord, {
        showModal(modalDialog(
            title = 'Update a Record',
            selectInput('team1a', 'Select Team to Remove Win From', 
                        choices = as.list(unique(rv$r$Team))),
            selectInput('team2a', 'Select Team to Remove Lose From', 
                        choices = as.list(unique(rv$r$Team))),
            easyClose = TRUE,
            footer = tagList(
                modalButton("Cancel"),
                actionButton("add1", "Correct")
            )
            
        ))
    })
    
    output$standings <- renderDataTable({
        
        currentYearRecords() %>% 
            filter(TotalPlayed >= 5) %>% 
            arrange(desc(Percentage), desc(Wins)) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15))
        
    })
    
    output$indStandings <- renderDataTable({
        
        player2 <- currentYearRecords() %>% 
            select(Player2, Wins, Loses) %>% 
            rename(Player1 = Player2)
        
        players <- currentYearRecords() %>% 
            select(Player1, Wins, Loses) %>% 
            rbind(player2) %>% 
            group_by(Player1) %>% 
            summarise(
                Wins = sum(Wins),
                      Loses = sum(Loses)) %>% 
            mutate(TotalPlayed = Wins + Loses,
                   Percentage = round(Wins/TotalPlayed, 2)
            ) %>% 
            arrange(desc(Percentage), desc(Wins)) %>% 
            filter(TotalPlayed >= 5) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15))
        
    })
    
    output$teams <- renderDataTable({
        
        currentYearRecords() %>% 
            select(Team, Player1, Player2, TotalPlayed, lastFive) %>% 
            arrange(desc(TotalPlayed)) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15))
        
    })
    
    output$overallStanding <- renderDataTable({
        
        overallRecords() %>% 
            filter(TotalPlayed >= 5) %>% 
            arrange(desc(Percentage), desc(Wins)) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15)) 
        
        
    })
    
    output$lifeIndStanding <- renderDataTable({
        
        player2 <- overallRecords() %>% 
            select(Player2, Wins, Loses) %>% 
            rename(Player1 = Player2)
        
        players <- overallRecords() %>% 
            select(Player1, Wins, Loses) %>% 
            rbind(player2) %>% 
            group_by(Player1) %>% 
            summarise(Wins = sum(Wins),
                      Loses = sum(Loses)) %>% 
            mutate(TotalPlayed = Wins + Loses,
                   Percentage = round(Wins/TotalPlayed, 2)
            ) %>% 
            arrange(desc(Percentage), desc(Wins)) %>% 
            filter(TotalPlayed >= 5) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15))
        
    })
    
    output$lifetimeTeams <- renderDataTable({
        
        overallRecords() %>% 
            select(Team, Player1, Player2, TotalPlayed) %>% 
            arrange(desc(TotalPlayed)) %>% 
            datatable(options = list(lengthMenu = c(5, 30, 50), pageLength = 15)) 
        
        
    })
    
    HTHWins <- reactive({  
        
        tempData <- rv$gL %>% 
        mutate(win = if_else(Team1Score>Team2Score, Team1, Team2),
               lose = if_else(Team1Score<Team2Score, Team1, Team2),
               scoreDifferenceWin = pmax(Team1Score,Team2Score)-pmin(Team1Score,Team2Score),
               scoreDifferenceLose = pmin(Team1Score,Team2Score) - pmax(Team1Score, Team2Score),
               winningScore = pmax(Team1Score, Team2Score),
               losingScore = pmin(Team1Score, Team2Score),
               matchUp = paste(win, "vs", lose),
               matchUp2 = paste(lose, 'vs', win)) %>% 
        select(matchUp, matchUp2, win, lose) %>% 
        mutate(winStr = str_split(matchUp, " ")[[1]][[1]],
               matchUpClean = ifelse(winStr == win, matchUp, matchUp2)) %>% 
        select(matchUpClean, win, lose) %>% 
        group_by(win, matchUpClean) %>% 
        mutate(winTotal = n()) %>% 
        ungroup() %>% 
        distinct()
        
        tempData
        
    })
    
    output$h2hPlot <- renderPlot({
        
        req(input$team1H2H)
        req(input$team2H2H)
        
        HTHWinsFilter <- HTHWins() %>% 
            filter((win == input$team1H2H & lose == input$team2H2H) |
                       (win == input$team2H2H & lose == input$team1H2H))
        
        if(NROW(HTHWinsFilter != 0)) {
            ggplot(HTHWinsFilter, aes(x = win, y = winTotal, fill = win)) + 
                geom_col() +
                theme_classic() +
                labs(
                    title = paste(input$team1H2H, "vs", input$team2H2H)
                )
        } else {
            text = paste(input$team1H2H, 'and', input$team2H2H, 'have not played \n',
                         'a game against each other yet.\nGet out there and',
                         "start playing!!")
            ggplot() + 
                annotate("text", x = 4, y = 25, size=8, label = text) + 
                theme_classic() +
                theme(panel.grid.major=element_blank(),
                      panel.grid.minor=element_blank())
        }
        

        
        
    })
    
    output$h2hText <- renderText({
        
        req(input$team1H2H)
        req(input$team2H2H)
        
        HTHWinsFilter <- HTHWins() %>% 
            filter((win == input$team1H2H & lose == input$team2H2H) |
                       (win == input$team2H2H & lose == input$team1H2H))
        
        text <- ""
        
        if(NROW(HTHWinsFilter != 0)) {
            line1 <- paste("In the match up of", input$team1H2H, 'vs', input$team2H2H)
            line2 <- paste("Team", HTHWinsFilter$win[[1]], 'has', HTHWinsFilter$winTotal[[1]], "wins and")
            line3 <- paste("Team", HTHWinsFilter$win[[2]], 'has', HTHWinsFilter$winTotal[[2]], 'wins')
            text <- paste(line1, line2, line3, sep = '\n')
            
        } else {
            
            line1 <- paste("In the match up of", input$team1H2H, 'vs', input$team2H2H)
            line2 <- paste("they are no results, since these teams have not played each other.")
            line3 <- paste("Get out there and start playing!!")
            
            text <- paste(line1, line2, line3, sep = '\n')
            
        }
        
        text
    })
    
    
    
    
    
    
}

shinyApp(ui = ui, server = server)
