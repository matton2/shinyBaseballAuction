
library(shiny)
library(tidyverse)
library(googledrive)

drive_download('2019 Hidden Ponds Bags', type = 'csv', overwrite = TRUE)


records <- read_csv('2019 Hidden Ponds Bags.csv')




records <- records %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/(TotalPlayed))

player2 <- records %>% 
  select(Player2, Wins, Loses) %>% 
  rename(Player1 = Player2)

playerStandings <- records %>% 
  select(Player1, Wins, Loses) %>% 
  rbind(player2) %>% 
  group_by(Player1) %>% 
  summarise(Wins = sum(Wins),
            Loses = sum(Loses)) %>% 
  mutate(TotalPlayed = Wins + Loses,
         Percentage = Wins/TotalPlayed
  ) %>% 
  arrange(desc(Percentage), desc(Wins)) %>% 
  head()
